/*
 * LCD_CSTMCHR.c
 *
 * Created: 5/28/2023 10:17:48 PM
 */

#include <io.h>
#include <alcd.h>
#include <delay.h>
void define_char(char flash*,char );

flash char emoji1[] = {
                    0b00011111,
                    0b00000000,
                    0b00001010,
                    0b00000000,
                    0b00010001,
                    0b00011111,
                    0b00000000,
                    0b00000000
                    };

flash char emoji2[] = {
                    0b00010001,
                    0b00001010,
                    0b00001010,
                    0b00000000,
                    0b00000000,
                    0b00011111,
                    0b00001110,
                    0b00000000
                    };
void main(void)
{


lcd_init(16);

define_char(emoji1,0);
define_char(emoji2,1);
lcd_gotoxy(0,0);
_lcd_write_data(0x06);
lcd_putsf("Hello ");
while (1)
    {
    lcd_gotoxy(6,0);
    lcd_putchar(0);
    delay_ms(500);
    lcd_gotoxy(6,0);
    lcd_putchar(1);
    delay_ms(500);

    }
}
/////////////////////////////////
void define_char(char flash *pc,char char_code)
{
char i,a;
a=(char_code<<3) | 0x40;
for (i=0; i<8; i++) lcd_write_byte(a++,*pc++);
}

