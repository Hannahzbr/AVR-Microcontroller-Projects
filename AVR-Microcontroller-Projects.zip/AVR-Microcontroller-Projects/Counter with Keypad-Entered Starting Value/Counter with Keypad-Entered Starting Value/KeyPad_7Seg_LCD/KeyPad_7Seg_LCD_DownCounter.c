#include <io.h>
#include <delay.h>
#include <alcd.h>
#include <stdio.h>
#include <stdbool.h>
//Function Prototype---------
char get_keyNum(void);
void disp(char dat[6]);
void num_decomp(long int);
//-------------------------------

//Global variable Declaration-------
char num_digit[6]={0,0,0,0,0,0};
char lcd_num[7] = {0,0,0,0,0,0,0};
const char num[10] ={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
const signed char key[16] = {7,8,9,-1,4,5,6,-2,1,2,3,-3,-4,0,-5,-6};
bool key_pressed = false;
//------------------------------
void main(void)
{

char key_num;
signed char entry;
unsigned long int number=0;
char dig_count=1;
int time_count = 0;

DDRA = 0x0F;
PORTA = 0xF0;
DDRC = 0xFF;
PORTC = 0x00;
DDRD = 0xFF;
PORTD = 0x00;
lcd_init(16);
lcd_putsf("Hello There!");
while (1)
    {
    key_num = get_keyNum();
    if((key_num != 20) & (key_num<=16))
    {
       entry = key[key_num-1];
       if(entry>=0 && dig_count<=6 && number<=999 )
       {
         number = number * 10 + entry;
         if(!(dig_count==1 && entry==0))    dig_count++;
         num_decomp(number);

            }
            if(entry==-4)
            {
                number=0;
                dig_count=1;
                num_decomp(number);
                }
            if(entry==-6)
            {
                while(number>0)
                {
                    if(time_count>100)
                    {
                    number--;
                    num_decomp(number);
                    sprintf(lcd_num,"%u",number);
                    lcd_clear();
                    lcd_gotoxy(0,0);
                    lcd_puts(lcd_num);
                    time_count=0;
                    delay_ms(1);
                    }
                    disp(num_digit);
                    time_count++;
                    delay_ms(1);
                    }

                sprintf(lcd_num,"%u",number);
                lcd_clear();
                lcd_gotoxy(0,0);
                lcd_puts(lcd_num);
                }

         sprintf(lcd_num,"%u",number);
                    lcd_clear();
                    lcd_gotoxy(0,0);
                    lcd_puts(lcd_num);
        }

        disp(num_digit);
    }
//Auxillary Functions
}

//Displays in 6Digit 7-Segment-----------
void disp(char dat[6])
{
int i;
    for(i=0;i<6;i++)
    {
        PORTD =~(1 << i);
        PORTC = num[dat[i]];
        delay_us(100);
        }
        }
//---------------------------------------

//decomposes Number into digits----------
void num_decomp(long int number)
{
    int j;

    for(j=0;j<6;j++)
    {
       num_digit[j] = number % (10);
       number = number / 10;
      }
       }
//--------------------------------------

char get_keyNum(void)
{
    char col=0,row=0;
    char key_num;
    PORTA=PORTA & 0xF0;
    if(((PINA & 0xF0) == 0xF0) & (key_pressed==true)) key_pressed=false;
    if(((PINA & 0xF0) != 0xF0) & (key_pressed==false))
    {
        delay_ms(50);

        for(row=1;row<=4;row++)
        {
            PORTA = (PORTA & 0xF0) | ~(1<<(row-1));
            delay_ms(10);
            for(col=1;col<=4;col++)
                {

                   if((((PINA & 0xF0) & ((0x10 << (col-1)))) == 0x00) & (key_pressed==false))
                   {
                    key_num = (row-1)*4 +col;
                    key_pressed=true;
                   // while((PINA & 0xF0)!=0xF0);

                        }
                    }

            }

    }
    else
    {
    key_num = 20;
    }

       return key_num;
        }