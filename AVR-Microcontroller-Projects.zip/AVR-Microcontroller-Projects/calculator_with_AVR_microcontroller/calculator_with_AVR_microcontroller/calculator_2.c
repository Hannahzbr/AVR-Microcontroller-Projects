#include <mega32.h>
#include <alcd.h>
#include <delay.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
// Declare your global variables here
int i = 0;
int j = 0;
int numbers[20];
int operators[20];
int length = 0;

char lcd[32];
int scan[] = {0xFE, 0xFD, 0xFB, 0xF7};
int arr_key[] = {7, 8, 9, 10,
                 4, 5, 6, 11,
                 1, 2, 3, 12,
                 15, 0, 14, 13};

void Print_array(int arr[], int len)
{
    // We use a for loop to print all the elements one by one
    for (i = 0; i < len; i++)
    {
        itoa(arr[i], lcd);
        lcd_puts(lcd);
    }

    return;
}

int keypad(void)
{
    int r, c, k;
    DDRD = 0x0F;
    PORTD = 0xFF;
    while (1)
    {
        for (r = 0; r < 4; r++)
        {
            c = 20;
            PORTD = scan[r];
            delay_us(10);
            if (PIND .4 == 0)
                c = 0;
            if (PIND .5 == 0)
                c = 1;
            if (PIND .6 == 0)
                c = 2;
            if (PIND .7 == 0)
                c = 3;

            if (c != 20)
            {
                k = arr_key[(r * 4) + c];
                while (PIND .4 == 0)
                    ;
                while (PIND .5 == 0)
                    ;
                while (PIND .6 == 0)
                    ;
                while (PIND .7 == 0)
                    ;
                delay_ms(10);
                return k;
            }
        }
    }
}

void print_lcd(int x)
{
    if (x < 10)
    {
        itoa(x, lcd);
        lcd_puts(lcd);
    }
    if (x == 10)
        lcd_putchar('/');
    if (x == 11)
        lcd_putchar('*');
    if (x == 12)
        lcd_putchar('-');
    if (x == 13)
        lcd_putchar('+');
    if (x == 14)
        lcd_putchar('=');
}

int get_num()
{
    int x = 0;
    int y = 0;
    length = 0;
    while (1)
    {
        x = keypad();
        if (x == 15)
        {
            lcd_clear();
            return 1;
        }
        print_lcd(x);
        if (x < 10)
        {
            y = y * 10 + x;
        }
        else
        {
            numbers[length] = y;
            operators[length] = x;
            length++;
            y = 0;
            if (x == 14)
            {
                break;
            }
        }
    }

    return 1;
}

void deleteElement(int *arr, int n, int x)
{
    // If x found in array
    if (x < n)
    {
        // reduce size of array and move all
        // elements one space ahead
        n = n - 1;
        for (j = x; j < n; j++)
        {
            *(arr + j) = *(arr + j + 1);
        }
    }
}

int moh(int op)
{
    switch (op)
    {
    case 1:

        for (i = 0; i < length; i++)
        {
            if (operators[i] == 10 || operators[i] == 11)
            {
                if (operators[i] == 10)
                {
                    numbers[i] = numbers[i] / numbers[i + 1];
                }
                else
                {
                    numbers[i] = numbers[i] * numbers[i + 1];
                }


                 deleteElement(operators, length, i);
                 deleteElement(numbers, length, i + 1);
                length--;
                return 1;
            }
        }

        break;
    case 2:

        for (i = 0; i < length; i++)
        {
            if (operators[i] == 12 || operators[i] == 13)
            {
                if (operators[i] == 12)
                {
                    numbers[i] = numbers[i] - numbers[i + 1];
                }
                else
                {
                    numbers[i] = numbers[i] + numbers[i + 1];
                }

                 deleteElement(operators, length, i);
                 deleteElement(numbers, length, i + 1);
                length--;
                return 1;
            }
        }

        break;

    default:
        break;
    }
    return 0;
}

void main(void)
{
    /*
   DDRA=(1<<DDA7) | (1<<DDA6) | (1<<DDA5) | (1<<DDA4) | (1<<DDA3) | (1<<DDA2) | (1<<DDA1) | (1<<DDA0);
   PORTA=(0<<PORTA7) | (0<<PORTA6) | (0<<PORTA5) | (0<<PORTA4) | (0<<PORTA3) | (0<<PORTA2) | (0<<PORTA1) | (0<<PORTA0);
   DDRB=(0<<DDB7) | (0<<DDB6) | (0<<DDB5) | (0<<DDB4) | (0<<DDB3) | (0<<DDB2) | (0<<DDB1) | (0<<DDB0);
   PORTB=(0<<PORTB7) | (0<<PORTB6) | (0<<PORTB5) | (0<<PORTB4) | (0<<PORTB3) | (0<<PORTB2) | (0<<PORTB1) | (0<<PORTB0);
   DDRC=(0<<DDC7) | (0<<DDC6) | (0<<DDC5) | (0<<DDC4) | (0<<DDC3) | (0<<DDC2) | (0<<DDC1) | (0<<DDC0);
   PORTC=(0<<PORTC7) | (0<<PORTC6) | (0<<PORTC5) | (0<<PORTC4) | (0<<PORTC3) | (0<<PORTC2) | (0<<PORTC1) | (0<<PORTC0);
   DDRD=(0<<DDD7) | (0<<DDD6) | (0<<DDD5) | (0<<DDD4) | (1<<DDD3) | (1<<DDD2) | (1<<DDD1) | (1<<DDD0);
   PORTD=(1<<PORTD7) | (1<<PORTD6) | (1<<PORTD5) | (1<<PORTD4) | (1<<PORTD3) | (1<<PORTD2) | (1<<PORTD1) | (1<<PORTD0);
   TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (0<<CS01) | (0<<CS00);
   TCNT0=0x00;
   OCR0=0x00;
   TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
   TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
   TCNT1H=0x00;
   TCNT1L=0x00;
   ICR1H=0x00;
   ICR1L=0x00;
   OCR1AH=0x00;
   OCR1AL=0x00;
   OCR1BH=0x00;
   OCR1BL=0x00;
   ASSR=0<<AS2;
   TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (0<<CS22) | (0<<CS21) | (0<<CS20);
   TCNT2=0x00;
   OCR2=0x00;
   TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);
   MCUCR=(0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
   MCUCSR=(0<<ISC2);
   UCSRB=(0<<RXCIE) | (0<<TXCIE) | (0<<UDRIE) | (0<<RXEN) | (0<<TXEN) | (0<<UCSZ2) | (0<<RXB8) | (0<<TXB8);
   ACSR=(1<<ACD) | (0<<ACBG) | (0<<ACO) | (0<<ACI) | (0<<ACIE) | (0<<ACIC) | (0<<ACIS1) | (0<<ACIS0);
   SFIOR=(0<<ACME);
   ADCSRA=(0<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (0<<ADPS2) | (0<<ADPS1) | (0<<ADPS0);
   SPCR=(0<<SPIE) | (0<<SPE) | (0<<DORD) | (0<<MSTR) | (0<<CPOL) | (0<<CPHA) | (0<<SPR1) | (0<<SPR0);
   TWCR=(0<<TWEA) | (0<<TWSTA) | (0<<TWSTO) | (0<<TWEN) | (0<<TWIE);*/
    lcd_init(16);

    while (1)
    {
        get_num();
          
        while (moh(1))
            ; 
            
        while (moh(2))
            ; 
              Print_array(numbers,length);
    }
}
