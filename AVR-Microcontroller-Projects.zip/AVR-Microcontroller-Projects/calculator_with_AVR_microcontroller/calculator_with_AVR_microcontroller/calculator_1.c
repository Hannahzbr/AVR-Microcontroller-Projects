#include <mega32.h>
#include <alcd.h>
#include <delay.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int num1 = 0;
int num2 = 0;
int op1 = 0;
int op2 = 0;

char lcd[32];
// Declare your global variables here
int scan[] = {0xFE, 0xFD, 0xFB, 0xF7};
int arr_key[] = {7, 8, 9, 10,
                 4, 5, 6, 11,
                 1, 2, 3, 12,
                 15, 0, 14, 13};
int flag =1;
int keypad(void)
{
    int r, c, k;
    DDRD = 0x0F;
    PORTD = 0xFF;
    while (1)
    {
        for (r = 0; r < 4; r++)
        {
            c = 20;
            PORTD = scan[r];
            delay_us(10);
            if (PIND.4 == 0)
                c = 0;
            if (PIND .5 == 0)
                c = 1;
            if (PIND .6 == 0)
                c = 2;
            if (PIND .7 == 0)
                c = 3;

            if (c != 20)
            {
                k = arr_key[(r * 4) + c];
                while (PIND .4 == 0)
                    ;
                while (PIND .5 == 0)
                    ;
                while (PIND .6 == 0)
                    ;
                while (PIND .7 == 0)
                    ;
                delay_ms(10);
                return k;
            }
        }
    }
}

void print_lcd(int x)
{
    if (x < 10)
    {
        itoa(x, lcd);
        lcd_puts(lcd);
    }
    if (x == 10)
        lcd_putchar('/');
    if (x == 11)
        lcd_putchar('*');
    if (x == 12)
        lcd_putchar('-');
    if (x == 13)
        lcd_putchar('+');
    if (x == 14)
        lcd_putchar('=');
}

int get_num(int *num, int *op)
{
    int x = 0;
    int y = 0;
    while (1)
    {
        x = keypad();
        if (x == 15)
        {
            lcd_clear();  
            num1=num2=op1=op2 =0;  
            flag =0;
            return 0;
        }
        print_lcd(x);
        if (x < 10)
        {
            y = y * 10 + x;
        }
        else
        {
            *num = y;
            *op = x;
            break;
        }
    }

    return 1;
}

void chek(int *res)
{

    if (op2 == 14)
    {
        switch (op1)
        {
        case 10:
            *res = num1 / num2;
            break;
        case 11:
            *res = num1 * num2;
            break;
        case 12:
            *res = num1 - num2;
            break;
        case 13:
            *res = num1 + num2;
            break;

        default:
            break;
        }
    }
    else
    {
        switch (op1)
        {
        case 10:
            num1 = num1 / num2;
            break;
        case 11:
            num1 = num1 * num2;
            break;
        case 12:
            num1 = num1 - num2;
            break;
        case 13:
            num1 = num1 + num2;
            break;

        default:
            break;
        }
        op1 = op2;
    }
}

void main(void)
{
    lcd_init(16);
    DDRA = 0xFF;
    DDRD = 0xFF;
    DDRC = 0xFF;
    while (1)
    {
        int res=0; 
        flag =1;
        get_num(&num1, &op1);
        while(flag){
           
            if( get_num(&num2, &op2) == 0){res = 0;break; }
            chek(&res);
            if(op2 ==14){break;}   
            
        }
        if(flag){
        itoa(res, lcd);
        lcd_puts(lcd);          
        }
        else{lcd_clear;}
    }
}
