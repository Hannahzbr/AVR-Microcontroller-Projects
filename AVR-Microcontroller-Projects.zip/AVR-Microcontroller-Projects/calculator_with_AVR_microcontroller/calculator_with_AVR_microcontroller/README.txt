 AVR Project: Four-Function Calculator

 Project Overview

This project implements a calculator using an AVR microcontroller, with support for the four basic arithmetic operations: addition, subtraction, multiplication, and division.

The program is written in C using the CodeVisionAVR development environment. The project includes the source code and a video explaining the code.

 Project Functionality

The calculator is designed to perform basic arithmetic calculations by processing numeric operands and applying the selected arithmetic operator.

The supported operations are:

- Addition (+): Adds two numbers.
- Subtraction (-): Subtracts one number from another.
- Multiplication (*): Multiplies two numbers.
- Division (/): Divides one number by another.

The calculator also supports combining arithmetic operations within the same expression, according to the implemented program logic.

The exact input method, output display, supported numeric range, operator precedence, and handling of division by zero depend on the actual source code and circuit implementation.

 Tools and Technologies

- AVR Microcontroller: Executes the calculator program.
- C Programming Language: Implements the arithmetic operations and program logic.
- CodeVisionAVR: Used for writing and developing the source code.
- Proteus Design Suite: Used for circuit simulation, if the corresponding project files are included.

 Project Files

The project directory includes the available files associated with the calculator implementation, such as:

- C source code developed in CodeVisionAVR
- Proteus circuit and simulation files, if included
- Video explaining the source code

Additional files required to compile or simulate the project should also be included when available.

Learning Objectives

This project provides practical experience with:

- Programming AVR microcontrollers in C
- Implementing arithmetic operations
- Processing numeric operands and operators
- Combining arithmetic operations in an expression
- Developing embedded applications using CodeVisionAVR
- Understanding program structure and arithmetic logic

 Code Explanation

A video explaining the source code is included with the project materials. It can be used alongside the source code to better understand the implementation.

If the video is hosted externally because of its file size, its link can be added here.

Simulation

If a Proteus project file is provided, open it in Proteus and run the simulation to examine the circuit behavior.

Successful simulation depends on the availability of the required files and the actual circuit configuration.


