/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator

Project :
Version :
Date    : 5/30/2023
Author  :
Company :
Comments:


Chip type               : ATmega32A
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32a.h>
#include <delay.h>
// Alphanumeric LCD functions
#include <alcd.h>

// Declare your global variables here


int x=8,y=0;/*X va Y makane character bar rooye LCD ro
			taghir khahand dad, va baraye inke charactere
            game hengame shooro'e game vasate safhe bashe
            meghdar avvalieye X ro 8 gozashtam.*/

/* Baraye tahvil daadane porozhe mikhastam charactere custom
dorost konam vali CodeVision bug dasht va ye errore alaki midad,
pas bakhshe charactere custom ro comment kardam va bejash "*" gozashtam!:
flash byte char0[8]={
0b10000000,
0b10001111,
0b10000011,
0b10000101,
0b10001001,
0b10010000,
0b10100000,
0b11000000};

void define_char(byte flash *pc,byte char_code)
{
byte i,a;
a=(char_code<<3) | 0x40;
for (i=0; i<8; i++) lcd_write_byte(a++,*pc++);
}
define_char(char0,99)
*/
void Update_LCD(void)/*Bad az inke user yeki az button haro feshar dad
						va mokhtassate (X,Y) avaz shod, in Function call
                        mishe ta "*" ro dar jaye jadidesh namayesh bede.*/
{
 lcd_clear();
 lcd_gotoxy(x,y);
 lcd_putsf("*");
}

void Blink_Green_LED(void)/*Bad az inke user yeki az button haro
							feshar dad va character bad az taghire makan
                            be samti ke karbar mikhad az kadreLCD(Border of LCD)
                            kharej nemishod, LEDSabzRang ye lahze cheshmak mizane
                            va khamush mishe ke be ma'nie "Ta'eede harekat" va
                            "Mojaz boodan be harekat be samti ke user khaste" hast.*/
{
 PORTD.6=1;
 delay_ms(100);
 PORTD.6=0;
}

void main(void)
{
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In
DDRA=(0<<DDA7) | (0<<DDA6) | (0<<DDA5) | (0<<DDA4) | (0<<DDA3) | (0<<DDA2) | (0<<DDA1) | (0<<DDA0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=T Bit2=T Bit1=T Bit0=T
PORTA=(0<<PORTA7) | (0<<PORTA6) | (0<<PORTA5) | (0<<PORTA4) | (0<<PORTA3) | (0<<PORTA2) | (0<<PORTA1) | (0<<PORTA0);

// Port B initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In
DDRB=(0<<DDB7) | (0<<DDB6) | (0<<DDB5) | (0<<DDB4) | (0<<DDB3) | (0<<DDB2) | (0<<DDB1) | (0<<DDB0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=T Bit2=T Bit1=T Bit0=T
PORTB=(0<<PORTB7) | (0<<PORTB6) | (0<<PORTB5) | (0<<PORTB4) | (0<<PORTB3) | (0<<PORTB2) | (0<<PORTB1) | (0<<PORTB0);

// Port C initialization
// Function: Bit7=In Bit6=In Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In
DDRC=(0<<DDC7) | (0<<DDC6) | (0<<DDC5) | (0<<DDC4) | (0<<DDC3) | (0<<DDC2) | (0<<DDC1) | (0<<DDC0);
// State: Bit7=T Bit6=T Bit5=T Bit4=T Bit3=T Bit2=T Bit1=T Bit0=T
PORTC=(0<<PORTC7) | (0<<PORTC6) | (0<<PORTC5) | (0<<PORTC4) | (0<<PORTC3) | (0<<PORTC2) | (0<<PORTC1) | (0<<PORTC0);

// Port D initialization
// Function: Bit7=Out Bit6=Out Bit5=In Bit4=In Bit3=In Bit2=In Bit1=In Bit0=In
DDRD=(1<<DDD7) | (1<<DDD6) | (0<<DDD5) | (0<<DDD4) | (0<<DDD3) | (0<<DDD2) | (0<<DDD1) | (0<<DDD0);
// State: Bit7=0 Bit6=P Bit5=P Bit4=P Bit3=P Bit2=P Bit1=P Bit0=P
PORTD=(0<<PORTD7) | (1<<PORTD6) | (1<<PORTD5) | (1<<PORTD4) | (1<<PORTD3) | (1<<PORTD2) | (1<<PORTD1) | (1<<PORTD0);

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTC Bit 0
// RD - PORTC Bit 1
// EN - PORTC Bit 2
// D4 - PORTC Bit 4
// D5 - PORTC Bit 5
// D6 - PORTC Bit 6
// D7 - PORTC Bit 7
// Characters/line: 16
lcd_init(16);
PORTD.6=1;/*In LED vaghti ke Vcc'e Device vasl mishe
			be moddate 5Sanie roshan mishe ke avvalan
            user bebine che LED hayee rooye dastgahesh
            hast, ham inke motmaen beshim LED kar mikone.*/
PORTD.7=1;/*(Mesle tozihate bala hast)*/
lcd_clear();
lcd_gotoxy(2,0);/*Jahate enteghale matne KHOSHAMD GOOEE
				be vasate safhe.*/
lcd_putsf("WELLCOME :)");
delay_ms(5000);
lcd_clear();
PORTD.6=0;/*in LED dar lahzeye vasl shodane Vcc'e Device
			roshan shode bood va hala hengame voorod be game
            khamoosh mishe.*/
PORTD.7=0;/*(Mesle tozihate bala)*/
while (1)
      {
       lcd_gotoxy(x,y);/*Raftan be location(8,0) baraye inke
       					 character az vasate safhe amade be
                         harekat bashe.*/
       lcd_putsf("*");/*namayeshe charactere game baraye shooro'e
       					game.*/

       if(PIND.0==0)/*PIND.0 dokmeye harekat be BALA hast
       				  ke dar in "if" detect khahad shod.*/
       {
        if(y==0)/*Agar dar satre balaee bashim va user dokmeye
        		  harekat be bala ro feshar bede, in bakhsh ejra mishe
                  va harekati anjam nemigire, va PIND.7 ke "LED'e Error" hast hamrah ba
                  zarbegire dokme (while()) ejra mishe.*/
        {
         while(PIND.0==0)PORTD.7=1;
         PORTD.7=0;
        }
        else/*Agar harekat be bala mojaz bashe in bakhsh ejra mishe
        	  va Y ro yek vahed kam mikone ta character be satre balaee
              biad. Sepas LED Sabz be nashaneye "Ta'eede Harekat" yek lahze
              roshan va bad khamoosh mishe.*/
        {
         y--;
         Blink_Green_LED();
        }
        Update_LCD();/*bad az taghir kardane X ya Y, in function call mishe
        			   ta makane character rooye LCD taghir peyda kone ya
                       (Update beshe).*/
        while(PIND.0==0);/*Zarbegire button: ta vaghti user button ro nagah dashte
        				   barname dar inje gir mikone ta vaghti ke user dastesh ro
                           az rooye button bardare va barname edeme peyda kone.*/
       }

       if(PIND.1==0)/*PIND.1 dokmeye harekat be PAEEN hast
       				  ke dar in "if" detect khahad shod.*/
       {
        if(y==1)
        {
         while(PIND.1==0)PORTD.7=1;
         PORTD.7=0;
        }
        else
        {
         y++;
         Blink_Green_LED();
        }
        Update_LCD();
        while(PIND.1==0);
       }

       if(PIND.2==0)/*PIND.1 dokmeye harekat be CHAP hast
       				  ke dar in "if" detect khahad shod.*/
       {
        if(x==0)
        {
		 while(PIND.2==0)PORTD.7=1;
         PORTD.7=0;
        }
        else
        {
         x--;
         Blink_Green_LED();
        }
        Update_LCD();
        while(PIND.2==0);
       }

       if(PIND.3==0)/*PIND.1 dokmeye harekat be RAST hast
       				  ke dar in "if" detect khahad shod.*/
       {
        if(x==15)
        {
         while(PIND.3==0)PORTD.7=1;
         PORTD.7=0;
        }
        else
        {
         x++;
         Blink_Green_LED();
        }
        Update_LCD();
        while(PIND.3==0);
       }
      }
}
